﻿namespace Completor.Core.Entities
{
    public interface IWordSet
    {
        Word[] UJ { get; }
        Word[] WI { get; }
    }
}