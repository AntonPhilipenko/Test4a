﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutoCompleteClient.Data
{
    public class UrlSetting
    {
        public string Url { get; set; }
    }
}
